
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UPI Intent Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: UpiIntentPage(),
    );
  }
}

class UpiIntentPage extends StatelessWidget {
  final String upiId = "example@upi";
  final String name = "Test Merchant";
  final String transactionNote = "Test Payment";
  final String amount = "1.00";

  Future<void> launchUPI() async {
    final uri = Uri.parse(
      "upi://pay?pa=$upiId&pn=$name&tn=$transactionNote&am=$amount&cu=INR",
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw "Could not launch UPI";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("UPI Intent Demo")),
      body: Center(
        child: ElevatedButton(
          onPressed: launchUPI,
          child: Text("Pay with UPI"),
        ),
      ),
    );
  }
}
